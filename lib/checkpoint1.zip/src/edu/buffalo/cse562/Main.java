package edu.buffalo.cse562;

import java.io.FileReader;
import java.io.File;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.Map;

import net.sf.jsqlparser.parser.*;
import net.sf.jsqlparser.statement.*;
import net.sf.jsqlparser.statement.create.table.*;
import net.sf.jsqlparser.statement.select.*;
import net.sf.jsqlparser.statement.insert.*;
import net.sf.jsqlparser.statement.update.*;
import net.sf.jsqlparser.statement.delete.*;

import edu.buffalo.cse562.checkpoint1.*;

public class Main {

  /**
   * Parse arguments and input files and dispatch requests to the appropriate 
   * system components
   * @param argsArray   An array of command line arguments
   */
  public static void main(String[] argsArray)
    throws Exception
  {
    SqlToRA translator = new SqlToRA();
    
    // For each file name detected in the arguments, parse it in.
    for(String f : argsArray){    
    
      CCJSqlParser parser = new CCJSqlParser(new FileReader(f));
      Statement s;
      
      // CCJSqlParser returns null once it hits EOF.
      while((s = parser.Statement()) != null){
        
        // Figure out what kind of statement we've just encountered

        if(s instanceof CreateTable){
          // SqlToRA extracts schema information from this create table 
          // statement and loads it into 'db'
          translator.loadTableSchema((CreateTable)s);

        } else if(s instanceof Select) {
          
          System.out.println("=== QUERY ===\n"+s);
          
          // SqlToRA uses the visitor pattern to convert a SelectBody into the
          // corresponding PlanNode subclasses.
          PlanNode plan = translator.selectToPlan(((Select)s).getSelectBody());

          // The visitor pattern doesn't play nicely with exceptions.  If an 
          // exception occurs during translation, checkError() will re-raise it 
          // here.
          translator.checkError();
          
          System.out.println("=== PLAN ===\n"+plan);

        } else { 
        
          // Utility method that produces an "Unsupported Feature" exception
          throw new Exception("Unhandled Statement Type");
        }
        

      } // END while((s = parser.Statement()) != null)

    } // END for(String f : argsArray)
  }
}